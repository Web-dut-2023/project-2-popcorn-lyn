from django.apps import AppConfig

class AuctionsConfig(AppConfig):
    name = 'auctions'
    default_auto_field = 'django.db.models.BigAutoField'